import matplotlib.pyplot as plt
import numpy as np

def plot_model_fit_history(history):
    history_key = history.history.keys()
    for key in history_key:
        plt.plot(history.history[key], label=key)
        plt.legend()
        plt.show()

from sklearn.metrics import mean_squared_error
def get_RMSE(val1, val2):
    RMSE = mean_squared_error(val1, val2, squared=False)
    return RMSE

def plot_two_values(val1, val2):
    plt.rcParams['figure.figsize'] =(18, 8)
    plt.plot(val1)
    plt.plot(val2)
    plt.show()
    

def plot_loss(history, title):
    plt.figure(figsize=(10,6))
    plt.plot(history.history['loss'], label='Train')
    plt.plot(history.history['val_loss'], label='Validation')
    plt.title(title)
    plt.xlabel('Nb Epochs')
    plt.ylabel('Loss')
    plt.legend()
    plt.show()
    
    val_loss = history.history['val_loss']
    min_idx = np.argmin(val_loss)
    min_val_loss = val_loss[min_idx]
    print('Minimum validation loss of {} reached at epoch {}'.format(min_val_loss, min_idx))