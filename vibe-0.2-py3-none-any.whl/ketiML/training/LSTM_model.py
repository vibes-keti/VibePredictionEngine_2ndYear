from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Bidirectional, TimeDistributed
from tensorflow.keras.layers import Conv1D
from tensorflow.keras.layers import MaxPooling1D
from tensorflow.keras.layers import Flatten
from tensorflow.keras.layers import Dense
from tensorflow.keras import backend
from tensorflow.keras.layers import ConvLSTM2D
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping
from tensorflow.keras.models import model_from_json

def checkpointer_earlystopper(model_name, model):
    #model_save
    
    import os
    dir_name = os.path.dirname(model_name)
    if not os.path.exists(dir_name):
        os.makedirs(dir_name)

    json_name = model_name+'.json'
    h5_name = model_name+'.h5'
    model_json = model.to_json()
    with open(json_name, 'w') as json_file:
        json_file.write(model_json)        
    checkpointer = ModelCheckpoint(filepath=h5_name
                                   , verbose=2
                                   , save_best_only=True)
    earlystopper = EarlyStopping(monitor='val_loss'
                                 , patience=10
                                 , verbose=2)
    
    return checkpointer, earlystopper

def rmse(y_true, y_pred):
	return backend.sqrt(backend.mean(backend.square(y_pred - y_true), axis=-1))
    
class LSTMModel():
    def __init__(self, learning_information):
        self.metrics = ['mse', 'mae', 'mape', rmse]
        self.learning_method = learning_information['learning_method']
        self.n_steps = learning_information['n_steps']
        self.n_seq = learning_information['n_seq']
        self.n_features = learning_information['n_features']
        self.learning_parameter = learning_information['learning_parameter']
    
    def model_build(self):
        learning_parameter = self.learning_parameter
        if self.learning_method == 'VanilaLSTM':
            self.model = self._build_VanilaLSTM( learning_parameter)
        elif self.learning_method == 'StackedLSTM':
            self.model = self._build_stakedLSTM(learning_parameter)
        elif self.learning_method == 'BiDirectionalLSTM':
            self.model = self._build_biDirectionalLSTM( learning_parameter)
        elif self.learning_method == 'CNNLSTM':
            self.model = self._build_CNNLSTM(learning_parameter)
        elif self.learning_method == 'ConvLSTM':
            self.model = self._build_ConvLSTM(learning_parameter)

        return self.model

    def _build_VanilaLSTM (self,   learning_parameter):
        first_unit_num = learning_parameter['first_unit_num']
        self.model=Sequential()
        self.model.add(LSTM(first_unit_num, activation='relu', input_shape=(self.n_steps, self.n_features)))
        self.model.add(Dense(1))
        self.model.compile(optimizer='adam', loss='mse', metrics= self.metrics)
        return self.model

    def _build_stakedLSTM (self, learning_parameter):
        # vanila LSTM
        first_unit_num = learning_parameter['first_unit_num']
        second_unit_num = learning_parameter['second_unit_num']
        self.model=Sequential()
        self.model.add(LSTM(first_unit_num, activation='relu', return_sequences=True, input_shape=(self.n_steps, self.n_features)))
        self.model.add(LSTM(second_unit_num, activation='relu'))
        self.model.add(Dense(1))
        self.model.compile(optimizer='adam', loss='mse', metrics=self.metrics)
        return self.model

    def _build_biDirectionalLSTM (self,  learning_parameter): 
        first_unit_num = learning_parameter['first_unit_num']
        self.model=Sequential()
        self.model.add(Bidirectional(LSTM(first_unit_num, activation='relu'), input_shape=(self.n_steps, self.n_features)))
        self.model.add(Dense(1))
        self.model.compile(optimizer='adam', loss='mse', metrics=self.metrics)
        return self.model

    def _build_CNNLSTM (self,  learning_parameter): 
        CNN_filter = learning_parameter['CNN_filter']
        first_unit_num = learning_parameter['first_unit_num']
        self.model=Sequential()
        self.model.add(TimeDistributed(Conv1D(filters=CNN_filter, kernel_size=1, activation='relu'), input_shape=(None, self.n_steps, self.n_features)))
        self.model.add(TimeDistributed(MaxPooling1D(pool_size=2)))
        self.model.add(TimeDistributed(Flatten()))
        self.model.add(LSTM(first_unit_num, activation='relu'))
        self.model.add(Dense(1))
        self.model.compile(optimizer='adam', loss='mse', metrics=self.metrics)

        return self.model


    def _build_ConvLSTM(self,  learning_parameter):
        ConvLSTM2D_p = learning_parameter['ConvLSTM2D']
        self.model = Sequential()
        self.model.add(ConvLSTM2D(filters=ConvLSTM2D_p, kernel_size=(1,2), activation='relu', input_shape=(self.n_seq, 1, self.n_steps, self.n_features)))
        self.model.add(Flatten())
        self.model.add(Dense(1))
        self.model.compile(optimizer='adam', loss='mse', metrics=self.metrics)
        return self.model


class Predict():
    def __init__(self, model_name):
        self.model_name = model_name
        self.json_file_name = model_name+'.json'
        self.h5_file_name = model_name +'.h5'

    def load_model(self):
        json_file = open(self.json_file_name, 'r')
        loaded_model_json = json_file.read()
        json_file.close()
        loaded_model = model_from_json(loaded_model_json)
        # load weights into new model
        loaded_model.load_weights(self.h5_file_name)
        self.model = loaded_model
        return loaded_model

    def predict(self, testX, verbose_num):
        yhat = self.model.predict(testX, verbose=verbose_num)
        return yhat
    
    def evaluate(self, testX, testy):
        results = self.model.evaluate(testX, testy, batch_size=128)
        print('test loss, test acc:', results)  

